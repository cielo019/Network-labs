import socket

# Create a socket object
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)  # AF_INET specifies the address family (IPv4)
# Get the hostname of the current machine
Host = socket.gethostname()

# Define the port number for the server
port = 12385
# Bind the socket with the address (Host, port)
s.bind((Host, port))
# maximum number of queued connections
s.listen(5)
print("Server is listening on port 12385...")

while True:
    # Accept a connection request from a client
    client_socket, client_address = s.accept()

    # Print a message when a new connection is established
    print(f"Connection established with {client_address}")






import socket

# AF_INET specifies the address family (IPv4)
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# Connect to the server
# 12385 is the port number the server is listening on
s.connect((socket.gethostname(), 12385))
print("Connected to the server!")




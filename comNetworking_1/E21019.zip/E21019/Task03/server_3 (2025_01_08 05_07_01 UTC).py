import socket
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)  # AF_INET specifies the address family (IPv4)
Host = socket.gethostname()  # Get the hostname of the current machine
port = 6300  # port num is 6300
# Bind the socket with the address (Host, port)
s.bind((Host, port))
s.listen(5)   # The maximum number of queued connections
print("Server is listening on port 6300...")

# Infinite loop to keep the server running and accept multiple client connections
while True:
    # Accept a connection request from a client
    client_socket, client_address = s.accept()
    print(f"Connection established with {client_address}")

    # Receive data from the client
    # recv(1024) specifies a buffer size of 1024 bytes
    # decode("utf-8") converts the received byte data to a string
    data = client_socket.recv(1024).decode("utf-8")
    if not data:  # Check if no data is received (client disconnected)
        print("No data received, closing connection.")
        client_socket.close()  # Close the client socket
        continue  # Move to the next client

    print(f"Received: {data}")
    # Send the same data back to the client (echo server functionality)
    # encode("utf-8") converts the string back to bytes for transmission
    client_socket.send(data.encode("utf-8"))
    client_socket.close()   # Close the client socket
s.close()

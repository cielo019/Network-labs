import socket
client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)  # AF_INET specifies the address family (IPv4)
# Get the hostname of the server (assuming the server is running on the same machine)
Host = socket.gethostname()
port = 6300  # port is 6300
client_socket.connect((Host, port))  # Establish a connection to the server
print("Connected to the server!")

# Send and receive messages in a loop
while True:
    # The input message will be sent to the server
    message = input("Enter message to send (or 'exit' to quit): ")

    # Check if the user wants to exit the loop
    if message.lower() == 'exit':
        print("Exiting the chat...")
        break
    # Send the message to the server
    # The message is encoded to bytes using UTF-8 before being sent
    client_socket.send(message.encode("utf-8"))

    # Receive the echoed message from the server
    # The recv(1024) method specifies a buffer size of 1024 bytes
    # The received byte data is decoded back into a string using UTF-8
    echoed_message = client_socket.recv(1024).decode("utf-8")
    print("Echoed from server:", echoed_message)

# Close the socket connection to release resources
client_socket.close()
print("Connection closed.")

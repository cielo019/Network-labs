import socket

# AF_INET specifies the address family (IPv4)
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.connect((socket.gethostname(), 5000))  # port num 5000
print("Connected to the server!")

# Receive the message from the server
# recv(1024) receives up to 1024 bytes from the server
# decode("utf-8") converts the received byte data back to a string
message = s.recv(1024).decode("utf-8")
print("Message from server:", message)

# Close the connection to free resources
s.close()

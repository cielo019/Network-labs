import socket

# AF_INET specifies the address family (IPv4)
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# Get the hostname of the current machine
Host = socket.gethostname()

# Define the port number for the server
port = 5000
# Bind the socket with the address (Host, port)
s.bind((Host, port))
# The maximum number of queued connections
s.listen(5)
print("Server is listening on port 5000...")

# Infinite loop to keep the server running and accept connections
while True:
    # Accept a connection request from a client
    # This returns a new socket object (client_socket) and the address of the client (client_address)
    client_socket, client_address = s.accept()
    print(f"Connection established with {client_address}")
    # message is encoded to bytes using UTF-8 encoding before sending
    message = "Hello! I am from the server!"
    client_socket.send(message.encode("utf-8"))

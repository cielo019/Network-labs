import socket

# Define the server addresses
server_addresses = [('localhost', 5678), ('localhost', 56789)]

# Create a UDP client socket
client_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

# Send messages to multiple servers
for server in server_addresses:
    message = f"Message to port {server[1]}"
    print(f"Sending to {server}: {message}")
    client_socket.sendto(message.encode(), server)

    # Receive response from each server
    data, server_info = client_socket.recvfrom(4096)
    print(f"Received from {server_info}: {data.decode()}")

client_socket.close()

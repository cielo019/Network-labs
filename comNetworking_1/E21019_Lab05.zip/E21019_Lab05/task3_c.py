import socket
# Create a UDP client socket
client_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

# Connect to the server
server_address = ('localhost', 3579)
client_socket.connect(server_address)
# Messages to send
messages = ["Hello, Server!", "How are you?", "Goodbye"]

for message in messages:
    # Send data to the server
    print(f"Sending: {message}")
    client_socket.send(message.encode())

    # Receive the response from the server
    data = client_socket.recv(4096)
    print(f"Received: {data.decode()}")

client_socket.close()

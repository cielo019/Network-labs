import socket

# Create UDP socket
server_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

# Bind the socket to an address and port
server_address = ('localhost', 4785)
server_socket.bind(server_address)

print("Server is running and waiting for client messages...")

while True:
    # Receive a message from the client
    data, client_address = server_socket.recvfrom(1024)
    received_number = data.decode()  # Decode the received data to a string

    print(f"Received {received_number} from {client_address}")

    # Echo the received number back to the client
    server_socket.sendto(data, client_address)
    print(f"Sent {received_number} back to {client_address}")

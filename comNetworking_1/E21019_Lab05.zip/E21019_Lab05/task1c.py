import socket

# Create a UDP socket
client_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

# Define the server address and port
server_address = ('localhost', 12345)

# Messages to send
messages = ["Hello, Server!", "How are you?", "Goodbye"]

for message in messages:
    # Send message to the server
    print(f"Sending: {message}")
    client_socket.sendto(message.encode(), server_address)

    # Receive the response from the server
    data, server = client_socket.recvfrom(4096)
    print(f"Received: {data.decode()}")

client_socket.close()

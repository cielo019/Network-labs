import socket
import time
client_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)  # Create UDP socket
server_address = ('localhost', 12345)
client_socket.settimeout(5)   # Define a timeout for receiving responses

# Input: Number of messages to send
n = int(input("Enter the number of requests to send (n): "))

# Send n sequential numbers to the server
for i in range(1, n + 1):
    message = str(i)
    client_socket.sendto(message.encode(), server_address)
    print(f"Sent: {message}")

print(f"All {n} messages sent. Waiting for responses...")
received_numbers = set()   # Collect responses from the server
start_time = time.time()

while time.time() - start_time < 5:  # Allow up to 5 seconds to receive responses
    try:
        data, _ = client_socket.recvfrom(1024)
        received_numbers.add(int(data.decode()))
    except socket.timeout:
        break  # Exit the loop if timeout occurs
missing_numbers = set(range(1, n + 1)) - received_numbers
print("Received numbers:", sorted(received_numbers))
print("Missing numbers:", sorted(missing_numbers))
print(f"Packet loss: {len(missing_numbers)} out of {n}")

import socket

# Create a UDP socket
client_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

# Server address
server_address = ("localhost", 62513)

# Number of requests to send
n = int(input("Enter the number of requests to send: "))

# Send requests
print(f"Sending {n} requests to the server...")
for i in range(1, n + 1):
    message = str(i)
    client_socket.sendto(message.encode(), server_address)

# Receive replies
print("Receiving replies:")
for _ in range(n):
    try:
        response, _ = client_socket.recvfrom(1024)
        print(f"Response: {response.decode()}")
    except socket.timeout:
        print("No response received for a message.")

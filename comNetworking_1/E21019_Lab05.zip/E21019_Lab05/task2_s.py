import socket
import threading

# Function for each server thread
def udp_server(port):
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    server_socket.bind(('localhost', port))
    print(f"Server started on port {port}")
    while True:
        # Receive data from the client
        data, client_address = server_socket.recvfrom(4096)
        print(f"Server on port {port} received: {data.decode()}")

        # Respond to the client
        response = f"Port {port} echo: {data.decode()}"
        server_socket.sendto(response.encode(), client_address)

# Start multiple server threads
server_ports = [5678 ,56789]
for port in server_ports:
    threading.Thread(target=udp_server, args=(port,), daemon=True).start()

# Keep the main thread alive
print("Servers are running. Press Ctrl+C to stop.")
try:
    while True:
        pass
except KeyboardInterrupt:
    print("Servers stopped.")

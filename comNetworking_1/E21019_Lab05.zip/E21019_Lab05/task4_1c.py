import socket
import time
n = int(input("Enter the number of requests to send (n): "))       # Define the number of requests to send
client_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)   # Create a UDP socket
server_address = ('localhost', 4785)
# Set a timeout for receiving responses
client_socket.settimeout(5)  # Wait up to 5 seconds for responses
# Send n sequential numbers to the server
for i in range(1, n + 1):
    message = str(i)  # Convert the number to a string
    client_socket.sendto(message.encode(), server_address)
    print(f"Sent: {message}")
print(f"All {n} messages sent. Waiting for responses...")
received_numbers = set()   # Collect responses from the server
start_time = time.time()
while time.time() - start_time < 5:  # Allow 5 seconds to collect responses
    try:
        data, _ = client_socket.recvfrom(1024)  # Receive data from the server
        received_numbers.add(int(data.decode()))  # Decode and add to the set
    except socket.timeout:
        break  # Exit if no more responses are received within the timeout
missing_numbers = set(range(1, n + 1)) - received_numbers
print("Received numbers:", sorted(received_numbers))
print("Missing numbers:", sorted(missing_numbers))

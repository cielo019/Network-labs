import socket

# Create a UDP socket
server_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

# Bind the socket to localhost and port 12345
server_socket.bind(("localhost", 62513))
print("UDP server is ready to receive messages.")

# Set the receive buffer size
buffer_size = 65535  # Modify this value as needed
server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF, buffer_size)
print(f"Receive buffer size set to {buffer_size} bytes.")

while True:
    # Receive message from client
    message, client_address = server_socket.recvfrom(1024)
    print(f"Received from client: {message.decode()}")

    # Echo the message back to the client
    server_socket.sendto(message, client_address)

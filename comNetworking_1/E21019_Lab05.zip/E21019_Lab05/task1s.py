import socket

# Create a UDP socket
server_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

# Bind the socket to the server address and port
server_address = ('localhost', 12345)
server_socket.bind(server_address)

print("UDP Server is running and waiting for client messages...")

while True:
    # Receive data from the client
    data, client_address = server_socket.recvfrom(4096)
    print(f"Received: {data.decode()} from {client_address}")

    # Send a response back to the client
    response = f"Echo: {data.decode()}"
    server_socket.sendto(response.encode(), client_address)

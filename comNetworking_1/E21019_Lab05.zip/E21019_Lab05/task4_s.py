import socket

# Create UDP socket
server_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
server_socket.bind(('localhost', 12345))

print("Server is running and waiting for client messages...")

while True:
    try:
        # Receive a message from the client
        data, client_address = server_socket.recvfrom(1024)
        received_number = data.decode()
        print(f"Received {received_number} from {client_address}")

        # Send the same number back to the client
        server_socket.sendto(data, client_address)
    except Exception as e:
        print(f"Error: {e}")
